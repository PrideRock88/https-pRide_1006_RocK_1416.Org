#!/usr/bin/env python
from bots import grammarcheck

if __name__=='__main__':
    grammarcheck.start()
